using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Sas;
using Microsoft.Azure.Functions.Worker.Http;
using Azure.Core;
using Azure.Identity;
using System.Net;
using Azure.Storage;
namespace Azure.CodeGuardUI;
public class GetBlobSasUri
{
    private readonly ILogger<GetBlobSasUri> _logger;
    public GetBlobSasUri(ILogger<GetBlobSasUri> logger)
    {
        _logger = logger;
    }
    [Function("GetBlobSasUri")]
    public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
    {
        _logger.LogInformation("C# HTTP trigger function processed a request.");
        string storageAccount = GetRequiredQueryParam(req, "storageAccount");
        string containerName = GetRequiredQueryParam(req, "containerName");
        string blobName = GetRequiredQueryParam(req, "blobName");
        int daysToLive = int.Parse(GetRequiredQueryParam(req, "daysToLive"));
        string storageKey = Environment.GetEnvironmentVariable("storageKey")!;
        DateTimeOffset startsOn = DateTimeOffset.UtcNow;
        DateTimeOffset expiresOn = startsOn.AddDays(daysToLive);
        StorageSharedKeyCredential credential = new StorageSharedKeyCredential(storageAccount, storageKey);
        BlobServiceClient blobServiceClient = new BlobServiceClient(
            new Uri($"https://{storageAccount}.blob.core.windows.net"),
            credential);
        BlobClient blobClient = blobServiceClient
            .GetBlobContainerClient(containerName)
            .GetBlobClient(blobName);
        BlobSasPermissions permissions = BlobSasPermissions.Read;
        BlobSasBuilder sasBuilder = new BlobSasBuilder
        {
            BlobContainerName = containerName,
            BlobName = blobName,
            Resource = "b",
            StartsOn = startsOn,
            ExpiresOn = expiresOn
        };
        sasBuilder.SetPermissions(permissions);
        string sasToken = sasBuilder.ToSasQueryParameters(credential).ToString();
        string url = blobClient.Uri + "?" + sasToken;
        HttpResponseData response = req.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
        await response.WriteStringAsync(url);
        return response;
    }
    internal static string GetRequiredQueryParam(HttpRequestData httpReq, string paramName)
    {
        string paramValue = httpReq.Query[paramName]!;
        if (string.IsNullOrEmpty(paramValue))
        {
            throw new Exception("Query parameter '" + paramName + "' is required");
        }
        else
        {
            return paramValue;
        }
    }
}
